

using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;

namespace SchoolManagement.Data;

public class ClassMetaData
{
   [Display(Name ="First Name ")] 
    public int? LecturerId { get; set; }
    [Display(Name ="Course ")] 
    public int? CourseId { get; set; }

   
}

[ModelMetadataType(typeof(ClassMetaData))]
public partial class Class{}