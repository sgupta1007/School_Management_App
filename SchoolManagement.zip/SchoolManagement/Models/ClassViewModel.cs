namespace SchoolManagement.Models
{
    public class ClassViewModel
    {
        public int Id { get; set; }
        public string CourseName {get;set;}
        public string Time { get; set; }
        public string LecturerName {get;set;}
    }
}